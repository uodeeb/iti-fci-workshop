function eman()
{
    console.log("yup");
    var container =document.getElementById('main');
    var image =document.createElement=('img');
    image.setAttribute("src",'https://besthqwallpapers.com/Uploads/5-4-2019/86249/thumb-bouquet-of-tulips-pink-tulips-postcard-spring-flowers-tulips-on-a-pink-background');
    container.appendChild(image);
};